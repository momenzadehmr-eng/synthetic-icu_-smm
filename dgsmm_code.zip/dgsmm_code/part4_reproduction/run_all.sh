#!/usr/bin/env bash
# Runs preprocessing once, then one DP training + generation run per seed in part2_configs/seeds.json.
# Usage: bash part4_reproduction/run_all.sh /path/to/mimiciv/3.1
set -euo pipefail
MIMIC="$1"; CFG=part2_configs/model_config.yaml; DATA=data/processed
python part1_preprocessing/preprocess_mimic4.py --mimic_dir "$MIMIC" --config $CFG --out $DATA
python part3_dp_accounting/privacy_accounting.py --sigma 1.1 --n_train "$(python -c "import numpy as np;print(len(np.load('$DATA/train.npz')['events']))")" --batch 64 --steps 12500 15000 --target_eps 2.3
for SEED in $(python -c "import json;print(' '.join(map(str,json.load(open('part2_configs/seeds.json'))['seeds'])))"); do
  python -m main.train --config $CFG --data $DATA --seed "$SEED" --out "runs/seed${SEED}" --generate 5000
done
