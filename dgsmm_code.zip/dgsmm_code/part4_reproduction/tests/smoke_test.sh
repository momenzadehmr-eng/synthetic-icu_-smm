#!/usr/bin/env bash
# End-to-end smoke test on FAKE data (random numbers). Checks that the code runs, nothing more.
set -euo pipefail
python part4_reproduction/tests/make_mock_mimic.py --out data/mock_mimic --n 300
python part1_preprocessing/preprocess_mimic4.py --mimic_dir data/mock_mimic --out data/mock_processed
python -m main.train --data data/mock_processed --seed 1 --out runs/smoke --max_epochs 2 --generate 16
python -m main.train --data data/mock_processed --seed 1 --out runs/smoke_nodp --max_epochs 2 --no_dp
echo "smoke test finished"
