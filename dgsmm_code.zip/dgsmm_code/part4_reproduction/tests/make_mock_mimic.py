"""Creates a tiny FAKE MIMIC-IV-shaped dataset (random numbers) to smoke-test the pipeline.
It is NOT real data and results from it mean nothing."""
import argparse, os
import numpy as np, pandas as pd

ap = argparse.ArgumentParser(); ap.add_argument("--out", default="data/mock_mimic"); ap.add_argument("--n", type=int, default=300)
a = ap.parse_args(); rng = np.random.RandomState(0)
for sub in ("hosp", "icu"): os.makedirs(os.path.join(a.out, sub), exist_ok=True)
base = pd.Timestamp("2150-01-01")
pat, adm, stay, dx, ch, lab, rx, pr = [], [], [], [], [], [], [], []
for i in range(a.n):
    sid, hid, tid = 1000 + i, 2000 + i, 3000 + i
    pat.append((sid, rng.choice(["F", "M"]), rng.randint(17, 90)))
    adm.append((hid, int(rng.rand() < 0.18)))
    t0 = base + pd.Timedelta(hours=int(rng.randint(0, 500))); los_h = int(rng.randint(30, 200)); t1 = t0 + pd.Timedelta(hours=los_h)
    stay.append((sid, hid, tid, t0, t1, los_h / 24))
    for code in rng.choice(["I10", "E119", "N179", "J960", "A419"], 2, replace=False): dx.append((hid, code, 10))
    for h in range(0, los_h, 1):
        for item, mu, sd in ((220045, 85, 15), (220179, 120, 20), (220210, 18, 5), (220277, 96, 3)):
            if rng.rand() < 0.7: ch.append((tid, t0 + pd.Timedelta(hours=h, minutes=int(rng.randint(0, 59))), item, rng.normal(mu, sd)))
    for item in (50912, 50813, 50971):
        for day in range(los_h // 24 + 1):
            lab.append((hid, item, t0 + pd.Timedelta(hours=24 * day + int(rng.randint(0, 20))), rng.normal(2, 1), "abnormal" if rng.rand() < .3 else None))
    for drug in rng.choice(["heparin", "furosemide", "norepinephrine", "insulin"], 2, replace=False):
        rx.append((hid, t0 + pd.Timedelta(hours=int(rng.randint(0, los_h))), drug))
    if rng.rand() < .3: pr.append((tid, t0 + pd.Timedelta(hours=int(rng.randint(0, los_h))), 225792))
def w(rows, cols, rel): pd.DataFrame(rows, columns=cols).to_csv(os.path.join(a.out, rel), index=False)
w(pat, ["subject_id", "gender", "anchor_age"], "hosp/patients.csv.gz")
w(adm, ["hadm_id", "hospital_expire_flag"], "hosp/admissions.csv.gz")
w(stay, ["subject_id", "hadm_id", "stay_id", "intime", "outtime", "los"], "icu/icustays.csv.gz")
w(dx, ["hadm_id", "icd_code", "icd_version"], "hosp/diagnoses_icd.csv.gz")
w(ch, ["stay_id", "charttime", "itemid", "valuenum"], "icu/chartevents.csv.gz")
w(lab, ["hadm_id", "itemid", "charttime", "valuenum", "flag"], "hosp/labevents.csv.gz")
w(rx, ["hadm_id", "starttime", "drug"], "hosp/prescriptions.csv.gz")
w(pr, ["stay_id", "starttime", "itemid"], "icu/procedureevents.csv.gz")
print("mock written to", a.out)
