# Reproducing the DGSMM experiments

Layout (one main code + four parts):

| Component | Folder | Content |
|---|---|---|
| Main code | `main/` | `dgsmm.py` (model, losses, sampler), `train.py` (DP-SGD training, generation) |
| Part 1 | `part1_preprocessing/` | `preprocess_mimic4.py` |
| Part 2 | `part2_configs/` | `model_config.yaml`, `seeds.json`, `clinical_rules.json` |
| Part 3 | `part3_dp_accounting/` | `privacy_accounting.py` |
| Part 4 | `part4_reproduction/` | this file, `requirements.txt`, `run_all.sh`, smoke test |

## Environment
Python 3.10+, `pip install -r part4_reproduction/requirements.txt`. Reported hardware: one NVIDIA RTX 4060 (8 GB VRAM).

## Steps
1. Obtain MIMIC-IV 3.1 from PhysioNet (credentialed access). Unzip so that `hosp/` and `icu/` are inside one folder.
2. Smoke test on fake data (minutes, no MIMIC needed): `bash part4_reproduction/tests/smoke_test.sh`
3. Full run: `bash part4_reproduction/run_all.sh /path/to/mimiciv/3.1`
   - preprocessing -> `data/processed/{train,val,test}.npz`, `artifacts.json`
   - accounting check printed to the console
   - one run per seed -> `runs/seed<k>/{best.pt, train_log.json, synthetic.npz}`
4. Results are reported as mean +/- 95% CI over the 10 seeds (mean +/- 1.96 SE), as in the manuscript.

## Before release - things the authors must fill in / verify
- `seeds.json`: replace the placeholder seeds with the ones actually used.
- `model_config.yaml`: every `[UNSPECIFIED]` value.
- `clinical_rules.json`: the curated guideline / ordering rules (empty template here).
- Item ids in `preprocess_mimic4.py` against MIMIC-IV `d_items` / `d_labitems`.
- Evaluation code (JSD, KS, membership inference, TSTR utility, ...) is NOT included in this package.
- Privacy: run `python part3_dp_accounting/privacy_accounting.py --sigma 1.1 --n_train <N_train> --batch 64 --steps <steps actually run>` and compare with `train_log.json`.
